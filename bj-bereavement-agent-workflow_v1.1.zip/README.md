# 北京市居民身后事务 AI Agent｜Executable Workflow (v1.1)

这套目录将政策知识库（v1.1）转换为可执行的 Agent Workflow。

## 目录

```text
schemas/
  case_profile.schema.json
  task.schema.json

workflow/
  state_machine.yaml
  defer_rules.yaml

rules/
  rules.yaml

examples/
  demo_case.json
  demo_case_high_risk.json   # v1.1 新增：验证高风险分流规则
```

## v1.1 变更说明

对照知识库 v1.1 Changelog，本次 workflow 修订内容：

1. **新增"确认死亡"可执行任务**：`rules.yaml` 新增 `DEATH_CONFIRM_001`（生成 `TASK_CONFIRM_DEATH`），`state_machine.yaml` 的 `CONFIRM_DEATH` 节点显式关联该任务，不再是"卡住但不提示"的空转自循环。

2. **纵深防御**：`rules.yaml` 中所有殡葬/户籍/养老/医保/公积金规则的 `when` 条件都新增了 `deceased.death.nature == 'NORMAL'` 的显式校验，不再仅依赖安全闸门在死亡证明获取阶段的一次性把关。`state_machine.yaml` 的 `hard_constraints` 中同时新增了引擎级要求：一旦 `mode == 'ESCALATED'` 或 `paused == true`，Rule Engine 必须在引擎层面停止评估所有非 SAFETY 规则。

3. **修正拼写错误**：`CREMATION_001` 的 `task_id` 由 `TASK_CREATION` 更正为 `TASK_CREMATION`。

4. **补全缺失的政策来源**：`ASH_001` 和 `PENSION_TYPE_001` 补上了此前缺失的 `official_source` / `last_verified`。

5. **新增三条高风险分流规则**：`CROSS_REGION_001`（跨区域/境外死亡）、`ETHNIC_RELIGIOUS_001`（民族/宗教特殊丧葬需求）、`HEIR_DISPUTE_001`（继承资格/亲属关系争议）。这三条不是主流程的顺序节点，而是"随时可能被触发"的旁路状态（见 `state_machine.yaml` 的 `side_channel_states`），触发后只阻止 Agent 在该具体子事项上自主判断，不阻断其他正在进行的正常事项。

6. **补全遗漏的 domain**：新增 `MEDICAL_BALANCE_001`（对应知识库 `MEDICAL_002`，职工医保个人账户余额，此前完全没有转换进 workflow）和 `FUNERAL_SUBSIDY_001`（丧葬补贴，此前整个 domain 缺失）。

7. **materials 结构化**：所有 `materials` 字段从纯字符串数组改为 `{name, requirement_level}` 对象数组，`requirement_level` 区分 `MANDATORY`（必须材料）和 `COMMON`（常见材料，可能因地区/情形不同而有出入）。

8. **修复伪并行 bug**：此前 `PERSONAL_POST_DEATH_ONE_STOP` 被标注为 `type: parallel`，但 transitions 是完全线性串行（户口→养老→医保→公积金）。v1.1 将户口注销、养老保险、医保、公积金四个分支改为真正并行——只共同依赖死亡证明已取得，彼此不再互相阻塞，与知识库"个人身后一件事，可集中办理"的理念一致。

9. **`policy_bound` 字段**：`task.schema.json` 新增该字段，`true` 表示该任务的建议依赖具体政策条文，此时 `official_source` 不允许为空；`false` 仅用于纯流程导航类任务（如确认死亡）。

10. **`family` 对象进入可执行 schema**：`case_profile.schema.json` 补上了此前只存在于知识库、未进入可执行层的 `family` 对象（含 `handler_relation_disputed`、`heir_dispute_reported` 等新字段），使 `HEIR_DISPUTE_001` 具备实际可用的数据支撑。

## 执行原则

1. Safety Rule 优先于所有普通 Rule；一旦 `mode == ESCALATED`，引擎层面停止评估所有非 SAFETY 规则（v1.1 强化为引擎级要求，不再只是文字约定）。
2. `UNKNOWN` 死亡性质不得自动进入正常死亡流程。
3. 除 SAFETY / 高风险分流规则外，所有下游规则必须自行重新校验 `death.nature == 'NORMAL'`（v1.1 新增，纵深防御）。
4. Rule Engine 决定"是否适用、下一步是什么"。
5. Policy RAG 负责解释政策依据。
6. LLM 只负责自然语言表达，不覆盖 Rule Engine。
7. `defer_allowed=true` 不代表法律上没有期限。
8. 政策事实必须绑定来源并保存 `last_verified`；`policy_bound == true` 的任务禁止 `official_source` 为空（v1.1 新增）。
9. `CROSS_REGION_001` / `ETHNIC_RELIGIOUS_001` / `HEIR_DISPUTE_001` 触发后，Agent 停止对该具体子事项的自主判断，但不阻断其他并行事项（v1.1 新增）。

## 主流程

```text
START
 ↓
CONFIRM_DEATH（关联 TASK_CONFIRM_DEATH）
 ↓
CHECK_DEATH_NATURE
 ├─ ABNORMAL / UNKNOWN → ABNORMAL_ESCALATED → STOP
 └─ NORMAL
      ↓
GET_DEATH_CERTIFICATE
 ↓
SELECT_FUNERAL_HOME
 ↓
BODY_TRANSPORT
 ↓
CREMATION
 ↓
ASH_ARRANGEMENT
 ↓
PERSONAL_POST_DEATH_ONE_STOP（真正并行，v1.1 修复）
 ├─ HUKOU_CANCELLATION → FUNERAL_SUBSIDY（v1.1 新增）
 ├─ PENSION_ROUTING
 ├─ MEDICAL_INSURANCE → MEDICAL_BALANCE（v1.1 新增，仅 EMPLOYEE 适用）
 └─ HOUSING_FUND
 ↓（任一分支完成即可推进，无需互相等待）
BASIC_CASE_COMPLETE
 ↓
POST_DEATH_AFFAIRS
 ↓
END

旁路（随时可能触发，不计入主流程顺序）:
 CROSS_REGION_001 / ETHNIC_RELIGIOUS_001 / HEIR_DISPUTE_001
```

## 后续工程建议

- 将 `rules.yaml` 加载到 Rule Engine，并在引擎层实现 `mode == ESCALATED` 时的全局拦截（不能只依赖规则自身 precondition）。
- 将 `state_machine.yaml` 加载到 Workflow Engine，注意 `side_channel_states` 与主流程 `states` 的触发逻辑是并行独立的。
- 将 `schemas/*.json` 用于 API / DB 校验；`task.schema.json` 中 `policy_bound == true` 时 `official_source` 非空的约束建议在应用层（而非纯 JSON Schema）强制校验。
- 将每个 Rule 的 `official_source` 和 `last_verified` 与 RAG 文档关联。
- 将 `task_id` 作为前端任务卡片和后端状态更新的稳定 ID。
- 建议为 `HEIR_DISPUTE_001` / `ETHNIC_RELIGIOUS_001` / `CROSS_REGION_001` 设计单独的人工审核队列，而不是与普通任务混在一起展示。
